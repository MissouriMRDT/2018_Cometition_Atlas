﻿using System;

namespace RED.Contexts
{
    [Serializable]
    public abstract class ConfigurationFile
    {
    }
}
