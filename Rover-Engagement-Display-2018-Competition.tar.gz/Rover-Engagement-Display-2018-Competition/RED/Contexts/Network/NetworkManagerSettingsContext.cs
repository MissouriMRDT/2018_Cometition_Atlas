﻿namespace RED.Contexts.Network
{
    public class NetworkManagerSettingsContext : ConfigurationFile
    {
        public bool EnableReliablePackets;
    }
}
