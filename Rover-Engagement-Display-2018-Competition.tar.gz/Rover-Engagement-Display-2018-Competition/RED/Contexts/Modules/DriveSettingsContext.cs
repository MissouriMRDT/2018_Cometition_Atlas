﻿namespace RED.Contexts.Modules
{
    public class DriveSettingsContext : ConfigurationFile
    {
        public int SpeedLimit;
        public bool UseLegacyDataIds;
    }
}
