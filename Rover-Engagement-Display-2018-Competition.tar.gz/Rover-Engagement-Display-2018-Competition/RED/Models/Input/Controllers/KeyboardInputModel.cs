﻿namespace RED.Models.Input.Controllers
{
    internal class KeyboardInputModel
    {
        internal bool Connected;
        internal float SpeedMultiplier = 1.0f;
    }
}