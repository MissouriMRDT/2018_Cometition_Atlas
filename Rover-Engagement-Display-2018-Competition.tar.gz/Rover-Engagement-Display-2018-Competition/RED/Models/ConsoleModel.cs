﻿using System;

namespace RED.Models
{
    internal class ConsoleModel
    {
        internal string _consoleText = String.Empty;
    }
}
