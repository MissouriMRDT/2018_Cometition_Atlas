﻿namespace RED.Models.Modules
{
    internal class DriveModel
    {
        internal int SpeedLeft;
        internal int SpeedRight;

        internal int SpeedLimit;
        internal bool UseLegacyDataIds;
    }
}
