﻿namespace RED.Models.Modules
{
    internal class AutonomyModel
    {
    }
}
