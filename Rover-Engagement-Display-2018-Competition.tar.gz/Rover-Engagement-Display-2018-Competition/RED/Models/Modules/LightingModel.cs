﻿namespace RED.Models.Modules
{
    internal class LightingModel
    {
        internal bool Enabled = false;
        internal bool HeadlightsEnabled = false;
        internal byte Red;
        internal byte Green;
        internal byte Blue;
    }
}
