﻿namespace RED.Models.Modules
{
    internal class GimbalModel
    {
        internal int PanIncrement = 5;
        internal int RollIncrement = 5;
        internal int TiltIncrement = 5;
        internal string ControlState;
    }
}
