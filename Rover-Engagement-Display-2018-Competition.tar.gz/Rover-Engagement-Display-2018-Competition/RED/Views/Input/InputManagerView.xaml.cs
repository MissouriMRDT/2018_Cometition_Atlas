﻿using System.Windows.Controls;

namespace RED.Views.Input
{
    /// <summary>
    /// Interaction logic for InputManagerView.xaml
    /// </summary>
    public partial class InputManagerView : UserControl
    {
        public InputManagerView()
        {
            InitializeComponent();
        }
    }
}
