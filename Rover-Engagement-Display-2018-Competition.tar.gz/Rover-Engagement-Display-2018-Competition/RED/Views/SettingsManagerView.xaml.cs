﻿using System.Windows.Controls;

namespace RED.Views
{
    /// <summary>
    /// Interaction logic for SettingsView.xaml
    /// </summary>
    public partial class SettingsManagerView : UserControl
    {
        public SettingsManagerView()
        {
            InitializeComponent();
        }
    }
}
