﻿using System.Windows.Controls;

namespace RED.Views.Tools
{
    /// <summary>
    /// Interaction logic for PingToolView.xaml
    /// </summary>
    public partial class PingToolView : UserControl
    {
        public PingToolView()
        {
            InitializeComponent();
        }
    }
}
