﻿using System.Windows.Controls;

namespace RED.Views.Tools
{
    /// <summary>
    /// Interaction logic for TelemetryLogToolView.xaml
    /// </summary>
    public partial class TelemetryLogToolView : UserControl
    {
        public TelemetryLogToolView()
        {
            InitializeComponent();
        }
    }
}
