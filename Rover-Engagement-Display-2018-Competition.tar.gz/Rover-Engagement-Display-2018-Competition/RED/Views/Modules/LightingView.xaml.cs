﻿using System.Windows.Controls;

namespace RED.Views.Modules
{
    /// <summary>
    /// Interaction logic for LightingView.xaml
    /// </summary>
    public partial class LightingView : UserControl
    {
        public LightingView()
        {
            InitializeComponent();
        }
    }
}
