﻿using System.Windows.Controls;

namespace RED.Views.Modules
{
    /// <summary>
    /// Interaction logic for ExternalControlsView.xaml
    /// </summary>
    public partial class ExternalControlsView : UserControl
    {
        public ExternalControlsView()
        {
            InitializeComponent();
        }
    }
}
