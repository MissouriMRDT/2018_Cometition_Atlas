﻿using System.Windows.Controls;

namespace RED.Views.Modules
{
    /// <summary>
    /// Interaction logic for GimbalView.xaml
    /// </summary>
    public partial class GimbalView : UserControl
    {
        public GimbalView()
        {
            InitializeComponent();
        }
    }
}
