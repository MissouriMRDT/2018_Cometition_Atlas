﻿using System.Windows.Controls;

namespace RED.Views.Modules
{
    /// <summary>
    /// Interaction logic for SensorView.xaml
    /// </summary>
    public partial class SensorView : UserControl
    {
        public SensorView()
        {
            InitializeComponent();
        }
    }
}
