﻿using System.Windows.Controls;

namespace RED.Views.Modules
{
    /// <summary>
    /// Interaction logic for DriveView.xaml
    /// </summary>
    public partial class DriveView : UserControl
    {
        public DriveView()
        {
            InitializeComponent();
        }
    }
}
