﻿using System.Windows.Controls;

namespace RED.Views.Modules
{
    /// <summary>
    /// Interaction logic for ArmView.xaml
    /// </summary>
    public partial class ArmView : UserControl
    {
        public ArmView()
        {
            InitializeComponent();
        }
    }
}
