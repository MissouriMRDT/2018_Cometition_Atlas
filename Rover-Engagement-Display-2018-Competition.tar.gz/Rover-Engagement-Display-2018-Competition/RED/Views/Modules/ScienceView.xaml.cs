﻿using System.Windows.Controls;

namespace RED.Views.Modules
{
    /// <summary>
    /// Interaction logic for ScienceView.xaml
    /// </summary>
    public partial class ScienceView : UserControl
    {
        public ScienceView()
        {
            InitializeComponent();
        }
    }
}
