﻿using System.Windows.Controls;

namespace RED.Views.Settings.Modules
{
    /// <summary>
    /// Interaction logic for DriveSettingsView.xaml
    /// </summary>
    public partial class DriveSettingsView : UserControl
    {
        public DriveSettingsView()
        {
            InitializeComponent();
        }
    }
}
