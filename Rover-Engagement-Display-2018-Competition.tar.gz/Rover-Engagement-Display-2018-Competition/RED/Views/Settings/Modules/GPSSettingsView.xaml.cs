﻿using System.Windows.Controls;

namespace RED.Views.Settings.Modules
{
    /// <summary>
    /// Interaction logic for GPSSettingsView.xaml
    /// </summary>
    public partial class GPSSettingsView : UserControl
    {
        public GPSSettingsView()
        {
            InitializeComponent();
        }
    }
}
