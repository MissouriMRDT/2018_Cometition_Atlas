﻿using System.Windows.Controls;

namespace RED.Views.Settings.Modules
{
    /// <summary>
    /// Interaction logic for ScienceSettingsView.xaml
    /// </summary>
    public partial class ScienceSettingsView : UserControl
    {
        public ScienceSettingsView()
        {
            InitializeComponent();
        }
    }
}
