﻿using System.Windows.Controls;

namespace RED.Views.Settings.Modules
{
    /// <summary>
    /// Interaction logic for PowerSettingsView.xaml
    /// </summary>
    public partial class PowerSettingsView : UserControl
    {
        public PowerSettingsView()
        {
            InitializeComponent();
        }
    }
}
