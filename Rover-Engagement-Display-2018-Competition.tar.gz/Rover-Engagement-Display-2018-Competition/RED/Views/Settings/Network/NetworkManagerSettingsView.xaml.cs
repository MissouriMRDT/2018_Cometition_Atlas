﻿using System.Windows.Controls;

namespace RED.Views.Settings.Network
{
    /// <summary>
    /// Interaction logic for NetworkManagerSettingsView.xaml
    /// </summary>
    public partial class NetworkManagerSettingsView : UserControl
    {
        public NetworkManagerSettingsView()
        {
            InitializeComponent();
        }
    }
}
