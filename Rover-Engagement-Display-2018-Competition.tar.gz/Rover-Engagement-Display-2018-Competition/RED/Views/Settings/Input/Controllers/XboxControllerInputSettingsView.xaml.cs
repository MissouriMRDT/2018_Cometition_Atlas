﻿using System.Windows.Controls;

namespace RED.Views.Settings.Input.Controllers
{
    /// <summary>
    /// Interaction logic for XboxControllerInputSettingsView.xaml
    /// </summary>
    public partial class XboxControllerInputSettingsView : UserControl
    {
        public XboxControllerInputSettingsView()
        {
            InitializeComponent();
        }
    }
}
